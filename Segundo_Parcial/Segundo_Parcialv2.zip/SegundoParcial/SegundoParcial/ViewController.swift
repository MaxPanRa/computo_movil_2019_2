//
//  ViewController.swift
//  SegundoParcial
//
//  Created by Gtec on 4/29/19.
//  Copyright © 2019 Gtec. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var trivia_1: UISwitch!
    @IBOutlet weak var trivia_2: UISwitch!
    @IBOutlet weak var trivia_3: UISwitch!
    
    @IBOutlet weak var trivia_congratz: UILabel!
    @IBOutlet weak var trivia_bg: UIView!
    @IBOutlet weak var trivia_code_text: UILabel!
    @IBOutlet weak var trivia_code: UILabel!
    
    @IBOutlet weak var congratulations_view: UIView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    @IBAction func changeSwitch(_ sender: Any) {
        if(!trivia_1.isOn && trivia_2.isOn && !trivia_3.isOn){
            print("El código promocional debería mostrarse");
        }else{
            print("Falló en la trivia");
        }
        }
}

