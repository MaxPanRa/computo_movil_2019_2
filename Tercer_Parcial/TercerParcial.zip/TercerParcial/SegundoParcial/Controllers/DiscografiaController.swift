//
//  discografiaController.swift
//  SegundoParcial
//
//  Created by Gtec on 5/8/19.
//  Copyright © 2019 Gtec. All rights reserved.
//

import UIKit

class DiscografiaController: UIViewController
{
    struct Album {
        var nombre:String
        var canciones:[String]
        var duraciones:[String]
        var cover:String
    }
    var album_allthelostsouls:Album = Album(
        nombre:"All the Lost Souls",
        canciones:
            ["1973",
             "One of the Brightest Stars",
             "I'll take Everything"],
        duraciones:
            ["4:40",
            "3:11",
            "3:05"],
        cover:"allthelostsouls.jpg"
    )
    var album_moonlanding:Album = Album(
        nombre:"Moon Landing",
        canciones:
        ["Face the Sun",
         "Satellites",
         "Bonfire Heart"],
        duraciones:
        ["4:02",
         "3:13",
         "3:59"],
        cover:"moonlanding.jpg"
    )
    var album_somekindoftrouble:Album = Album(
        nombre:"Some Kind of Trouble",
        canciones:
        ["Stay the Night",
         "Dangerous",
         "Best Laid Plans"],
        duraciones:
        ["3:25",
         "3:12",
         "3:30"],
        cover:"somekindoftrouble.jpg"
    )
    var album_theafterlove:Album = Album(
        nombre:"The Afterlove",
        canciones:
        ["Love me Better",
         "Bartender",
         "Lose My Number"],
        duraciones:
        ["3:38",
         "3:13",
         "3:28"],
        cover:"theafterlove.jpg"
    )
    
    var albumActual = String()
    
    @IBOutlet weak var albumName: UILabel!
    @IBOutlet weak var imagenAlbum: UIImageView!
    @IBOutlet weak var song_1: UILabel!
    @IBOutlet weak var song_2: UILabel!
    @IBOutlet weak var song_3: UILabel!
    @IBOutlet weak var dura_1: UILabel!
    @IBOutlet weak var dura_2: UILabel!
    @IBOutlet weak var dura_3: UILabel!
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        if(albumActual == album_theafterlove.nombre){
            albumName.text = album_theafterlove.nombre
            imagenAlbum.image =  UIImage(named:album_theafterlove.cover)
            song_1.text = album_theafterlove.canciones[0]
            song_2.text = album_theafterlove.canciones[1]
            song_3.text = album_theafterlove.canciones[2]
            dura_1.text = album_theafterlove.duraciones[0]
            dura_2.text = album_theafterlove.duraciones[1]
            dura_3.text = album_theafterlove.duraciones[2]
        } else if(albumActual == album_moonlanding.nombre){
            albumName.text = album_moonlanding.nombre
            imagenAlbum.image =  UIImage(named:album_moonlanding.cover)
            song_1.text = album_moonlanding.canciones[0]
            song_2.text = album_moonlanding.canciones[1]
            song_3.text = album_moonlanding.canciones[2]
            dura_1.text = album_moonlanding.duraciones[0]
            dura_2.text = album_moonlanding.duraciones[1]
            dura_3.text = album_moonlanding.duraciones[2]
        } else if(albumActual == album_allthelostsouls.nombre){
            albumName.text = album_allthelostsouls.nombre
            imagenAlbum.image =  UIImage(named:album_allthelostsouls.cover)
            song_1.text = album_allthelostsouls.canciones[0]
            song_2.text = album_allthelostsouls.canciones[1]
            song_3.text = album_allthelostsouls.canciones[2]
            dura_1.text = album_allthelostsouls.duraciones[0]
            dura_2.text = album_allthelostsouls.duraciones[1]
            dura_3.text = album_allthelostsouls.duraciones[2]
        } else if(albumActual == album_somekindoftrouble.nombre){
            albumName.text = album_somekindoftrouble.nombre
            imagenAlbum.image =  UIImage(named:album_somekindoftrouble.cover)
            song_1.text = album_somekindoftrouble.canciones[0]
            song_2.text = album_somekindoftrouble.canciones[1]
            song_3.text = album_somekindoftrouble.canciones[2]
            dura_1.text = album_somekindoftrouble.duraciones[0]
            dura_2.text = album_somekindoftrouble.duraciones[1]
            dura_3.text = album_somekindoftrouble.duraciones[2]
        }
        
    }
}
