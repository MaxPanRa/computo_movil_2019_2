//
//  FirstSouvenirsController.swift
//  SegundoParcial
//
//  Created by Gtec on 5/21/19.
//  Copyright © 2019 Gtec. All rights reserved.
//

import UIKit

class FirstSouvenirsController: UIViewController {
    
    var total=0.00;
    var totalRef=0.00;
    //Para Camiseta
    @IBOutlet weak var camisetaQuantity: UITextField!
    var camisetaPrize=600.00;
    
    //Para Chaqueta
    @IBOutlet weak var chaquetaQuantity: UITextField!
    var chaquetaPrize=1500.00;
    
    //Codigo Promocional
    @IBOutlet weak var codigoPromo: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        let souvenirsSegue =  segue.destination as! SouvenirsController
        totalRef=0.00;
        if(camisetaQuantity.text==""){
            camisetaQuantity.text="0"
        }
        if(chaquetaQuantity.text==""){
            chaquetaQuantity.text="0"
        }
        
        totalRef = totalRef + (chaquetaPrize * Double(chaquetaQuantity.text!)!)
        totalRef = totalRef + (camisetaPrize * Double(camisetaQuantity.text!)!)
        if(codigoPromo.text=="123456"){
            total = totalRef * 0.50
            souvenirsSegue.promo = true
        }else{
            total = totalRef
            souvenirsSegue.promo = false
        }
        souvenirsSegue.precioTotal=total
        
    }

}
