//
//  ViewController.swift
//  SegundoParcial
//
//  Created by Gtec on 4/29/19.
//  Copyright © 2019 Gtec. All rights reserved.
//

import UIKit

class FirstTriviaController: UIViewController {
    
    
    // VARIABLES PARA TRIVIA
    var winnerBool = false;
    
    @IBOutlet weak var trivia_1: UISwitch!
    @IBOutlet weak var trivia_2: UISwitch!
    @IBOutlet weak var trivia_3: UISwitch!
    override func viewDidLoad() {
        super.viewDidLoad()
        if(!trivia_1.isOn && trivia_2.isOn && !trivia_3.isOn){
            winnerBool=true
        }else{
            winnerBool=false
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        let triviaSegue =  segue.destination as! TriviaController
        
        if(!trivia_1.isOn && trivia_2.isOn && !trivia_3.isOn){
            winnerBool=true
        }else{
            winnerBool=false
        }
        
        triviaSegue.winner=winnerBool;
        
    }
    
}

