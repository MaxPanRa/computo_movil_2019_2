//
//  SouvenirsController.swift
//  SegundoParcial
//
//  Created by Gtec on 5/21/19.
//  Copyright © 2019 Gtec. All rights reserved.
//

import UIKit

class SouvenirsController: UIViewController {

    var precioTotal=0.00;
    var promo=false;
    @IBOutlet weak var totalMostrado: UITextField!
    @IBOutlet weak var promoText: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        totalMostrado.text="$\(precioTotal) MXN"
        if(promo){
        promoText.text="REBAJADO AL 50%"
        }else{
            promoText.text=""
        }
    }

}
