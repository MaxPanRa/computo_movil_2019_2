//
//  TriviaController.swift
//  SegundoParcial
//
//  Created by Gtec on 5/21/19.
//  Copyright © 2019 Gtec. All rights reserved.
//

import UIKit

class TriviaController: UIViewController {
    
    
    var winner = false;
    @IBOutlet weak var tituloGrande: UILabel!
    @IBOutlet weak var tituloPequenio: UILabel!
    @IBOutlet weak var codigoPromo: UILabel!
    @IBOutlet weak var fondoMensaje: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if(winner){
            tituloGrande.text="FELICIDADES"
            tituloPequenio.text="Tu Código Promocional"
            codigoPromo.text="123456"
            fondoMensaje.backgroundColor=UIColor.yellow
        }else{
            tituloGrande.text="HAS PERDIDO"
            tituloPequenio.text="Inténtalo Nuevamente"
            codigoPromo.text="NO_PROMO"
            fondoMensaje.backgroundColor=UIColor.gray
        }
        
    }

}
