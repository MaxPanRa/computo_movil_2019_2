//
//  ViewController.swift
//  SegundoParcial
//
//  Created by Gtec on 4/29/19.
//  Copyright © 2019 Gtec. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    // VARIABLES PARA DISCOGRAFIA
    var nombre_album=String();
    
    override func viewDidLoad() {
        super.viewDidLoad()
        nombre_album = "";
    }
    
    // FUNCIONES PARA DISCOGRAFIA
    @IBAction func allthelostsouls(_ sender: Any) {
        if let sender = sender as? UIButton{
            nombre_album="All The Lost Souls"
        }
    }
    @IBAction func moonlanding(_ sender: Any) {
        if let sender = sender as? UIButton{
            nombre_album="Moon Landing"
        }
    }
    @IBAction func somekindoftrouble(_ sender: Any) {
        if let sender = sender as? UIButton{
            nombre_album="Some Kind of Trouble"
        }
    }
    
    @IBAction func theafterlove(_ sender: Any) {
        if let sender = sender as? UIButton{
         nombre_album="The Afterlove"
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        //Segue Discografia
        let discografiaSegue =  segue.destination as! DiscografiaController
        print(nombre_album)
        discografiaSegue.albumActual = nombre_album
        
    }

}

